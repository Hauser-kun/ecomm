<?php

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Stock Photo Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }
    </style>
</head>

<body class="bg-gray-100 flex items-center justify-center h-screen">

    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-2xl font-bold mb-6 text-center">Sign In</h2>
        <form action="../code.php" method="post">
            <div class="mb-4">
                <label for="username" class="block text-gray-700 mb-2">Username:</label>
                <input type="text" id="name" name="name" class="w-full p-3 border border-gray-300 rounded-lg" required>
            </div>
            <div class="mb-4">
                <label for="email" class="block text-gray-700 mb-2">Email:</label>
                <input type="email" id="email" name="email" class="w-full p-3 border border-gray-300 rounded-lg" required>
            </div>
            <div class="mb-4">
                <label for="password" class="block text-gray-700 mb-2">Password:</label>
                <input type="password" id="password" name="password" class="w-full p-3 border border-gray-300 rounded-lg" required>
            </div>
            <button type="submit" name="save_user" class="w-full bg-yellow-500 text-white py-3 px-6 rounded-full text-lg hover:bg-yellow-600">Create</button>
        </form>
        <p class="mt-4 text-center">Don't have an account? <a href="login.php" class="text-yellow-500">Log In</a></p>
        <p class="mt-4 text-center"><a href="index.php" class="text-gray-500">Back to Home</a></p>
    </div>

</body>

</html>