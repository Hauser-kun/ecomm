<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - Stock Photo Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100">

   <?php
   include '../includes/header.php';

   ?>
    <!-- Content -->
    <div class="container mx-auto px-4 py-8">

        <!-- Shop Items -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
            <!-- Sample Item 1 -->
            <div class="bg-white rounded-lg overflow-hidden shadow-lg">
                <img src="https://via.placeholder.com/400x300" alt="Stock Photo 1" class="w-full h-48 object-cover">
                <div class="p-4">
                    <h3 class="text-xl font-bold mb-2">Stock Photo 1</h3>
                    <p class="text-gray-700 mb-2">$10.99</p>
                    <button class="bg-yellow-500 text-white py-2 px-4 rounded-full text-sm hover:bg-yellow-600">Add to Cart</button>
                </div>
            </div>

            <!-- Sample Item 2 -->
            <div class="bg-white rounded-lg overflow-hidden shadow-lg">
                <img src="https://via.placeholder.com/400x300" alt="Stock Photo 2" class="w-full h-48 object-cover">
                <div class="p-4">
                    <h3 class="text-xl font-bold mb-2">Stock Photo 2</h3>
                    <p class="text-gray-700 mb-2">$12.99</p>
                    <button class="bg-yellow-500 text-white py-2 px-4 rounded-full text-sm hover:bg-yellow-600">Add to Cart</button>
                </div>
            </div>

            <!-- Sample Item 3 -->
            <div class="bg-white rounded-lg overflow-hidden shadow-lg">
                <img src="https://via.placeholder.com/400x300" alt="Stock Photo 3" class="w-full h-48 object-cover">
                <div class="p-4">
                    <h3 class="text-xl font-bold mb-2">Stock Photo 3</h3>
                    <p class="text-gray-700 mb-2">$8.99</p>
                    <button class="bg-yellow-500 text-white py-2 px-4 rounded-full text-sm hover:bg-yellow-600">Add to Cart</button>
                </div>
            </div>

            <!-- Add more items as needed -->
        </div>

    </div>

</body>
</html>
