<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Photo - Stock Photo Hub</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS for additional styling -->
    <style>
        
        .container {
            max-width: 600px;
            margin: 100px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 30px;
            text-align: center;
        }

        .custom-file-label {
            overflow: hidden;
        }

        .custom-file-input:focus~.custom-file-label {
            border-color: #495057;
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <?php
    include '../includes/header.php';
    ?>
    <!-- Main content -->
    <div class="container">
        <h2>Upload Your Photo</h2>
        <form id="uploadForm" enctype="multipart/form-data">
            <div class="form-group">
                <label for="photoFile">Choose a Photo:</label>
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="photoFile" name="photoFile" accept="image/*" required>
                    <label class="custom-file-label" for="photoFile">Select file...</label>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
    </div>

    <!-- Bootstrap JS and additional scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Update file input label with selected filename
        document.getElementById('photoFile').addEventListener('change', function(e) {
            var fileName = e.target.files[0].name;
            var nextSibling = e.target.nextElementSibling;
            nextSibling.innerText = fileName;
        });

        // Handle form submission
        document.getElementById('uploadForm').addEventListener('submit', function(e) {
            e.preventDefault(); // Prevent actual form submission

            // Simulate upload process (replace with actual AJAX upload)
            var formData = new FormData(this);
            // You can add AJAX request here to upload the file to server

            alert('File uploaded successfully!'); // Example alert (replace with actual feedback)

            // Reset form after submission (optional)
            this.reset();
        });
    </script>
</body>

</html>