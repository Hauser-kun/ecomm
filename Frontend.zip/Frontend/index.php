<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Photo Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <style>
        /* Custom CSS for 3D button effect */
        .btn-3d {
            background-color: #fbbf24;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            box-shadow: 0 4px #c99700;
            transition: all 0.2s ease-in-out;
        }

        .btn-3d:hover {
            box-shadow: 0 2px #c99700;
            transform: translateY(2px);
        }

        /* Custom CSS for the logo font */
        .logo-text {
            font-family: 'Montserrat', sans-serif;
            font-size: 1.5rem;
            color: white;
        }
    </style>
</head>

<body class="bg-gray-100 text-gray-900">

    <!-- Navbar -->
    <?php
    include '../includes/header.php';
    include '../includes/subheader.php';

    ?>

    <!-- Main Content -->
    <main class="py-12">
        <!-- Home Section -->
        <section id="home" class="container mx-auto px-4">
            <div class="text-center">
                <h2 class="text-3xl font-semibold mb-4">Welcome to Stock Photo Hub</h2>
                <p class="text-lg text-gray-700 mb-8">Your go-to destination for high-quality stock photos.</p>
                <a href="#gallery" class="bg-yellow-500 text-white py-3 px-6 rounded-full text-lg hover:bg-yellow-600">Browse Gallery</a>
            </div>
        </section>

        <!-- Gallery Section -->
        <section id="gallery" class="container mx-auto px-4 py-12">
            <h2 class="text-3xl font-semibold text-center mb-8">Photo Gallery</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <!-- Photo 1 -->
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <img src="images/photo-1.jpg" alt="City skyline at night" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <p class="text-gray-700">City skyline at night</p>
                    </div>
                </div>
                <!-- Photo 2 -->
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <img src="images/photo-2.jpg" alt="Aerial view of beach and ocean" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <p class="text-gray-700">Aerial view of beach and ocean</p>
                    </div>
                </div>
                <!-- Photo 3 -->
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <img src="images/photo-3.jpg" alt="Mountain landscape with lake" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <p class="text-gray-700">Mountain landscape with lake</p>
                    </div>
                </div>
                <!-- Photo 4 -->
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <img src="images/photo-4.jpg" alt="Sunset over a field" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <p class="text-gray-700">Sunset over a field</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- About Us Section -->
        <section id="about" class="container mx-auto px-4 py-12 bg-white rounded-lg shadow-lg">
            <h2 class="text-3xl font-semibold text-center mb-8">About Us</h2>
            <p class="text-lg text-gray-700 text-center">We provide a wide range of high-quality stock photos to meet all your needs. Whether you're a designer, marketer, or content creator, you'll find the perfect image in our collection.</p>
        </section>

        <!-- Contact Section -->
        <section id="contact" class="container mx-auto px-4 py-12">
            <h2 class="text-3xl font-semibold text-center mb-8">Contact Us</h2>
            <form action="submit_form.php" method="post" class="max-w-lg mx-auto bg-white p-8 rounded-lg shadow-lg">
                <div class="mb-4">
                    <label for="name" class="block text-gray-700 mb-2">Name:</label>
                    <input type="text" id="name" name="name" class="w-full p-3 border border-gray-300 rounded-lg" required>
                </div>
                <div class="mb-4">
                    <label for="email" class="block text-gray-700 mb-2">Email:</label>
                    <input type="email" id="email" name="email" class="w-full p-3 border border-gray-300 rounded-lg" required>
                </div>
                <div class="mb-4">
                    <label for="message" class="block text-gray-700 mb-2">Message:</label>
                    <textarea id="message" name="message" class="w-full p-3 border border-gray-300 rounded-lg" required></textarea>
                </div>
                <div>
                    <button type="submit" class="w-full bg-yellow-500 text-white py-3 px-6 rounded-full text-lg hover:bg-yellow-600">Send Message</button>
                </div>
            </form>
        </section>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white text-center py-6">
        <div class="container mx-auto px-4">
            <p>&copy; 2024 Stock Photo Hub. All rights reserved.</p>
        </div>
    </footer>

    <!-- JavaScript -->
    <script>
        document.getElementById('joinButton').addEventListener('click', function() {
            window.location.href = 'signup.html';
        });
    </script>
</body>

</html>